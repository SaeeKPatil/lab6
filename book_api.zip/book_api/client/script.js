document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('book-form');
    const bookList = document.getElementById('book-list');

    // Fetch and display books
    const fetchBooks = async () => {
        const response = await fetch('/api/books');
        const books = await response.json();
        bookList.innerHTML = '';
        books.forEach(book => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${book.title} by ${book.author} (ISBN: ${book.isbn})</span>
                <div>
                    <button class="icon-btn" onclick="editBook('${book.isbn}', '${book.title}', '${book.author}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="icon-btn" onclick="deleteBook('${book.isbn}')">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            bookList.appendChild(li);
        });
    };

    // Add a new book
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const author = document.getElementById('author').value;
        const isbn = document.getElementById('isbn').value;

        const response = await fetch('/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author, isbn })
        });

        if (response.ok) {
            fetchBooks(); // Refresh the book list
            form.reset(); // Clear the form fields
        } else {
            alert('Error adding book');
        }
    });

    // Delete a book
    window.deleteBook = async (isbn) => {
        if (confirm('Are you sure you want to delete this book?')) {
            const response = await fetch(`/api/books/${isbn}`, { method: 'DELETE' });
            if (response.ok) {
                fetchBooks(); // Refresh the book list
            } else {
                alert('Error deleting book');
            }
        }
    };

    // Edit a book
    window.editBook = (isbn, title, author) => {
        document.getElementById('title').value = title;
        document.getElementById('author').value = author;
        document.getElementById('isbn').value = isbn;

        form.onsubmit = async (e) => {
            e.preventDefault();
            const updatedTitle = document.getElementById('title').value;
            const updatedAuthor = document.getElementById('author').value;

            const response = await fetch(`/api/books/${isbn}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title: updatedTitle, author: updatedAuthor })
            });

            if (response.ok) {
                fetchBooks(); // Refresh the book list
                form.reset();
                form.onsubmit = addBookHandler; // Reset form behavior
            } else {
                alert('Error updating book');
            }
        };
    };

    const addBookHandler = async (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const author = document.getElementById('author').value;
        const isbn = document.getElementById('isbn').value;

        const response = await fetch('/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author, isbn })
        });

        if (response.ok) {
            fetchBooks();
            form.reset();
        } else {
            alert('Error adding book');
        }
    };

    form.onsubmit = addBookHandler;

    // Initial fetch of books
    fetchBooks();
});
