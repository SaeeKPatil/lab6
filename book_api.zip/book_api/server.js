const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3003;

// Middleware
app.use(express.json());
app.use(express.static('client')); // Serve static files from the client folder

// Load books data
const booksFilePath = path.join(__dirname, 'data', 'books.json');
const loadBooks = () => JSON.parse(fs.readFileSync(booksFilePath));
const saveBooks = (books) => fs.writeFileSync(booksFilePath, JSON.stringify(books, null, 2));

// GET all books
app.get('/api/books', (req, res) => {
    const books = loadBooks();
    res.json(books);
});

// POST a new book
app.post('/api/books', (req, res) => {
    const books = loadBooks();
    const newBook = req.body;

    // Simple validation
    if (!newBook.title || !newBook.author || !newBook.isbn) {
        return res.status(400).json({ message: 'Title, author, and ISBN are required.' });
    }

    books.push(newBook);
    saveBooks(books);

    res.status(201).json({ message: 'Book added successfully', book: newBook });
});

// PUT (update) a book by ISBN
app.put('/api/books/:isbn', (req, res) => {
    const books = loadBooks();
    const { isbn } = req.params;
    const updatedBook = req.body;

    // Find the book index
    const bookIndex = books.findIndex(book => book.isbn === isbn);
    if (bookIndex === -1) {
        return res.status(404).json({ message: 'Book not found' });
    }

    // Update the book details
    books[bookIndex] = { ...books[bookIndex], ...updatedBook };
    saveBooks(books);

    res.json({ message: 'Book updated successfully', book: books[bookIndex] });
});

// DELETE a book by ISBN
app.delete('/api/books/:isbn', (req, res) => {
    const books = loadBooks();
    const { isbn } = req.params;

    // Find the book index
    const bookIndex = books.findIndex(book => book.isbn === isbn);
    if (bookIndex === -1) {
        return res.status(404).json({ message: 'Book not found' });
    }

    // Remove the book from the array
    const deletedBook = books.splice(bookIndex, 1);
    saveBooks(books);

    res.json({ message: 'Book deleted successfully', book: deletedBook });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
